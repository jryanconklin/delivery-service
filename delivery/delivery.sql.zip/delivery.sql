-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 06, 2016 at 06:56 PM
-- Server version: 5.6.28
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `delivery`
--
CREATE DATABASE IF NOT EXISTS `delivery` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `delivery`;

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `address_type` varchar(50) DEFAULT NULL,
  `address_one` varchar(100) DEFAULT NULL,
  `address_two` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(10) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `address_type`, `address_one`, `address_two`, `city`, `state`, `zip`, `country`) VALUES
(1, 'Business', '345 SE Taylor St', 'C/O Angel May', 'Portland', 'OR', 97214, 'United States of America'),
(2, 'Business', '2079 W Burnside St', 'Store 101', 'Portland', 'OR', 97209, 'United States of America'),
(3, 'Business', '555 SW Oak St', 'US Bancorp Tower', 'Portland', 'OR', 97204, 'United States of America'),
(4, 'Business', '2940 NE Alberta St', 'Alberta Location', 'Portland', 'OR', 97211, 'United States of America'),
(5, 'Business', '624 E Burnside St', 'Burnside', 'Portland', 'OR', 97214, 'United States of America'),
(6, 'Business', '5320 NE 33rd Ave', 'Concordia', 'Portland', 'OR', 97211, 'United States of America'),
(7, 'Business', '720 SW Broadway', 'SW Broadway', 'Portland', 'OR', 97205, 'United States of America'),
(8, 'Residential', '2166 N Place Ave', 'C/O John Peoples', 'Portland', 'OR', 97217, 'United States of America'),
(9, 'Residential', '5128 N Real Ave', 'C/O Marian Peoples', 'Portland', 'OR', 97217, 'United States of America');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(70) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `phone`, `email`, `password`, `address_id`) VALUES
(1, 'John Peoples', '503-123-4567', 'john@person.com', '1!2@3#4$4$5%6^', 8),
(2, 'Marian Person', '503-123-4567', 'marian@person.com', 'goodpassword', 9);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `details` varchar(255) DEFAULT NULL,
  `instructions` varchar(255) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `rider_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `riders`
--

CREATE TABLE `riders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(70) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `available` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `riders_services`
--

CREATE TABLE `riders_services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rider_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(70) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`) VALUES
(1, 'Game Store'),
(2, 'Fast Food'),
(3, 'Restaurant'),
(4, 'Flower Shop'),
(5, 'Grocery Store'),
(6, 'Coffee Shop');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(70) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `name`, `description`, `phone`, `url`, `photo`, `type_id`, `address_id`) VALUES
(1, 'Guardian Games', 'The biggest game store in Portland! Guardian Games is centrally located in the SE Industrial Area of Portland, Oregon. Just a few blocks North of OMSI, at the corner of MLK and Taylor Street near the Morrison Bridge off-ramp.', '503-238-4000', 'http://www.ggportland.com/', '/../img/guardiangames.jpg', 1, 1),
(2, 'Taco Bell', 'What is there to say? This is Taco Bell. Do you need fast food fast that are maybe tacos depending on your definition? Taco Bell is here for you. Live mas, but like, in a genuine way, you know?', '800-822-6235', 'https://www.tacobell.com/', '/../img/tacobell.jpg', 2, 2),
(3, 'Geranium Lake Flowers', 'Celebrated flower shop crafting creative arrangements, with delivery & event-management services.', '503-228-1920', 'http://www.geraniumlake.com/', '/../img/geraniumlake.jpg', 4, 3),
(4, 'Stella Taco', 'Stella Taco\nbringing Austin-style tacos to the Great Northwest. Serving Up The Relaxed And Fun Feel Of Texas Style Street Tacos, Grilled Quesadillas\nand Frozen Cocktails.', '971-407-3705', 'http://www.stellatacopdx.com/', '/../img/stellataco.jpg', 3, 4),
(5, 'Sizzle Pie', 'Death to False Pizza. Sizzle Pie has been serving up meat, veggie and vegan pies in Portland for almost a decade.', '503-234-7437', 'http://www.sizzlepie.pizza/', '/../img/sizzlepie.jpg', 3, 5),
(6, 'New Seasons', 'New Seasons Market brings\ndelicious, healthy food from local\nfarmers, producers, ranchers & fishermen\nto our communities.', '503-288-3838', 'https://www.newseasonsmarket.com/our-stores/concordia/', '/../img/newseasons-concordia', 5, 6),
(7, 'Starbucks', 'Starbucks makes coffee and then sells it to you. Good for drinking and the having of caffeine.', '503-223-2488', 'https://www.starbucks.com/', '/../img/starbucks.jpg', 5, 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `riders`
--
ALTER TABLE `riders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `riders_services`
--
ALTER TABLE `riders_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `riders`
--
ALTER TABLE `riders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `riders_services`
--
ALTER TABLE `riders_services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
